﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Concentration
{
    public partial class Form1 : Form
    {
        int secondCard = NOT_SELECTED;
        const int NUM_CARDS = 14;
        const int NUM_CARD_TYPES = 7;
        const int NOT_SELECTED = -1;
        int firstCard = NOT_SELECTED;
        int secondCard = NOT_SELECTED;

        Card[] cards = new Card[NUM_CARDS];

        public Form1()
        {
            InitializeComponent();
            CreateDeck();
            ShuffleDeck();
            AssignPictureBoxes();
        }

        private void aBOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Guess who programmed this? If you said Chris Logan, you would be correct");
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void CreateDeck()
        {
            //create new card in the array
            for(int i = 0; i < NUM_CARDS; i++)
            {
                cards[i] = new Card();
            }

            //set all picture boxes to a card
            int j = 0;
            for(int i = 0; i < NUM_CARD_TYPES; i++)
            {
                cards[j++].SetCardType(i);
                cards[j++].SetCardType(i);
            }
        }

        private void AssignPictureBoxes()
        {
            //first row
            cards[0].SetPictureBox(pictureBox1);
            cards[1].SetPictureBox(pictureBox2);
            cards[2].SetPictureBox(pictureBox3);
            cards[3].SetPictureBox(pictureBox4);
            cards[4].SetPictureBox(pictureBox5);
            cards[5].SetPictureBox(pictureBox6);
            cards[6].SetPictureBox(pictureBox7);

            //second row
            cards[7].SetPictureBox(pictureBox8);
            cards[8].SetPictureBox(pictureBox9);
            cards[9].SetPictureBox(pictureBox10);
            cards[10].SetPictureBox(pictureBox11);
            cards[11].SetPictureBox(pictureBox12);
            cards[12].SetPictureBox(pictureBox13);
            cards[13].SetPictureBox(pictureBox14);
            
        }
        private void ShuffleDeck()
        {
            for (int i = 0; i < 100; i++)
            {
                int pos1 = r.Next(0, NUM_CARDS);
                int pos2 = r.Next(0, NUM_CARDS);
                //switch cards at those positions
                int temp = cards[pos1].GetCardType(); //save card1
                cards[pos1].SetCardType(cards[pos2].GetCardType()); //copy card 2 to card 1
                cards[pos2].SetCardType(temp); //copy temp to card 1
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            FlipCard(0);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            FlipCard(1);
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            FlipCard(2);
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            FlipCard(3);
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            FlipCard(4);
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            FlipCard(5);
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            FlipCard(6); 
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            FlipCard(7);
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            FlipCard(8);
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            FlipCard(9);
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {
            FlipCard(10);
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            FlipCard(11);
        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {
            FlipCard(12);
        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {
            FlipCard(13);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //stop timer
            timer1.Stop();
            cards[firstCard].Hide();
            cards[secondCard].Hide();

            //clear selections
            firstCard = NOT_SELECTED;
            secondCard = NOT_SELECTED;
        }
        private void FlipCard(int index)
        {
            if(firstCard == NOT_SELECTED)
            {
                firstCard = index;
            }
            else if(secondCard == NOT_SELECTED)
            {
                secondCard = index;
            }
            
        }
    }
}
