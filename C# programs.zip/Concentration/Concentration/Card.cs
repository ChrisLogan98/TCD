﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace Concentration
{
    class Card
    {
        public int cardType;
        private bool matched = false;
        PictureBox pictureBox;
        

        const int KNIGHT = 0;
        const int SWORD = 1;
        const int TORCH = 2;
        const int COINS = 3;
        const int SHIELD = 4;
        const int LAMP = 5;
        const int DYNAMITE = 6;
        const int CARD_BACK = 7;
        const int NO_CARD = 8;

        static SoundPlayer flipSound = new SoundPlayer(Properties.Resources.CardFlip);

        public Card()
        {

        }

        public void Show()
        {
            if(matched == false)
            {
                flipSound.PlaySync();
                
                if(cardType == KNIGHT)
                {
                    pictureBox.(Properties.Resources.card_knight);
                }
                else if(cardType == SWORD)
                {
                    pictureBox.(Properties.Resources.card_sword);
                }
                else if(cardType == TORCH)
                {
                    pictureBox.(Properties.Resources.card_torch);
                }
                else if(cardType == COINS)
                {
                    pictureBox.(Properties.Resources.card_coins);
                }
                else if(cardType == SHIELD)
                {
                    pictureBox.(Properties.Resources.card_shield);
                }
                else if(cardType == LAMP)
                {
                    pictureBox.(Properties.Resources.card_lamp);
                }
                else if(cardType == DYNAMITE)
                {
                    pictureBox.(Properties.Resources.card_dynamite);
                }
            }
        }

        //turn card back over
        public void Hide()
        {
            if(matched == true)
            {
                pictureBox.Show(global::Concentration.Properties.Resources.blank);
            }
            else
            {
                pictureBox.Show(global::Concentration.Properties.Resources.card_back);
            }
        }

        public bool GetMatched()
        {
            return matched;
        }

        public void SetMatched()
        {
            matched = true;
        }

        public void SetPictureBox(PictureBox box)
        {
            this.pictureBox = box;
        }

        public void SetCardType(int card)
        {
            cardType = card;
        }

        public int GetCardType()
        {
            return cardType;
        }


        public void Reset()
        {
            matched = false;
        }

    }
    
}
