﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Etch_A_Sketch
{
    class MyCursor
    {
        int x;
        int y;

        public MyCursor()
        {
            x = 200;
            y = 150;
        }

        public void Draw(Graphics g)
        {
            g.FillRectangle(Brushes.Gray, x - 2, y - 2, 4, 4); //draw a 4x4 rectangle
        }

        public void Up()
        {
            y--;
        }
        
        public void Down()
        {
            y++;
        }

        public void Left()
        {
            x--;
        }

        public void Right()
        {
            x++;
        }
    }
}
