﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Etch_A_Sketch
{
    public partial class Form1 : Form
    {
        MyCursor cursor = new MyCursor();

        public Form1()
        {
            InitializeComponent();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aBOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Why don't you try a real Etch-A-Sketch?");
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a' || e.KeyChar == 'A')
            { //left
                cursor.Left();
            }
            else if (e.KeyChar == 'd' || e.KeyChar == 'D')
            { //right
                cursor.Right();
            }
            else if(e.KeyChar == 'w' || e.KeyChar == 'W')
            { //up
                cursor.Up();
            }
            else if(e.KeyChar == 's' || e.KeyChar == 'S')
            { //down
                cursor.Down();
            }
            //pictureBox1.Invalidate();
            cursor.Draw(pictureBox2.CreateGraphics());
        }

        private void pictureBox2_Paint(object sender, PaintEventArgs e)
        {
            cursor.Draw(e.Graphics);
        }

        private void nEWGAMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            pictureBox2.Invalidate();
        }
    }
}
