﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Caterpiller
{
    class Game
    {
        int score = 0;
        bool gameOver = false;

        Caterpiller caterpiller = new Caterpiller();
        Flower flower = new Flower(25, 25, global::Caterpiller.Properties.Resources.flower);

        public Game()
        {
            gameOver = false;
        }

        public void Reset()
        {
            if (gameOver)
            {
                score = 0;
                caterpiller.Reset();
                flower.Reposition();
                gameOver = false;
            }
        }

        public void GoRight()
        {
            caterpiller.GoRight();
        }

        public void GoLeft()
        {
            caterpiller.GoLeft();
        }

        public void GoUp()
        {
            caterpiller.GoUp();
        }

        public void GoDown()
        {
            caterpiller.GoDown();
        }

        public void Update()
        {
            if(!gameOver)
            {
                caterpiller.Update();
                //hit flower?
                if(CaterpillerTouchingFlower())
                {
                    caterpiller.Grow();
                    flower.Reposition();
                }

                //hit wall?
                if(caterpiller.GetX() < 0 || caterpiller.GetX() > 600 || caterpiller.GetY() < 0 || caterpiller.GetY() > 400)
                {
                    gameOver = true;
                }

                if(caterpiller.HitSelf())
                {
                    gameOver = true;
                }
            }
        }

        public void Draw(Graphics g)
        {
            g.Clear(Color.Green);
            flower.Draw(g);
            caterpiller.Draw(g);
        }

        private bool CaterpillerTouchingFlower()
        {
            return caterpiller.GetBounds().IntersectsWith(flower.GetBounds());
        }
    }
}
