﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chat_Program
{
    [Serializable]
    class ChatMsg
    {
        public string msg;

        public ChatMsg(String s)
        {
            msg = s;
        }
    }
}
