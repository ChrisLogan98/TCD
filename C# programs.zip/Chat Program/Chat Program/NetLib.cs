﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace NetLib
{
    class UDPConnection
    {

        const int DISCONNECTED=0;
        const int SERVER = 1;
        const int CLIENT = 2;
        int state = DISCONNECTED;
       
        IPEndPoint remoteEndPoint;
    
        byte[] buffer = new byte[2048];
        UdpClient udpClient = new UdpClient();
      
        string remoteIP = "";
        int remotePort = 0;
        IPAddress remoteAddr;

        //establish the connection
        public void StartServer(int port)
        {
            try
            {
                udpClient = new UdpClient(port, AddressFamily.InterNetwork);
                state = SERVER;
                remoteIP = "";
                remotePort = 0;
                remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
            } 
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }

        }

        public string GetLocalIP()
        {
            string IP4Address = String.Empty;

            foreach (IPAddress IPA in Dns.GetHostAddresses(Dns.GetHostName()))
            {
                if (IPA.AddressFamily == AddressFamily.InterNetwork)
                {
                    IP4Address = IPA.ToString();
                    break;
                }
            }

            return IP4Address;
        }


        public void Close()
        {
            try
            {
                udpClient.Close();
                state = DISCONNECTED;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }

        /*Creates a network connection and sends a ConnectMsg to the specified IP and port
         */
        public void StartClient(string remoteIP, int port)
        {
            try
            {
                udpClient = new UdpClient(AddressFamily.InterNetwork);
                
                IPHostEntry ipHostInfo = Dns.GetHostEntry(remoteIP);
                remotePort = port;
                this.remoteIP = remoteIP;
                remoteAddr = ipHostInfo.AddressList[0];
                remoteEndPoint = new IPEndPoint(remoteAddr, port);
                state = CLIENT;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
        }


        /* 
         * Sends a message a message to the remote endpoint
         * If the remote endpoint was not setup, an exception will occur
         */
        public void Send(Object message)
        {
            if (udpClient != null)
            {
                byte[] msg = ObjectToByteArray(message);
                udpClient.Send(msg, msg.Length, remoteIP, remotePort);
            }
            
        }

        /*This function returns true if the connection has data to read
         */
        public bool HasData()
        {
            if (state == DISCONNECTED) 
                return false;
            return (udpClient.Available > 0);
        }

        public virtual object Receive()
        {
            if (HasData())
            {

                byte[] data = udpClient.Receive(ref remoteEndPoint);
                
                if (state == SERVER)
                {
                    remoteAddr = remoteEndPoint.Address;
                    remotePort = remoteEndPoint.Port;
                    remoteIP = remoteAddr.ToString();
                }
                  //textBox1.Text += "data received, " + data.Length + " bytes\r\n";

                BinaryFormatter bf = new BinaryFormatter();    
                Stream stream = new MemoryStream(data);
                Object o = bf.Deserialize(stream);
                return o;
            }
            else
            {
                return null;
            }
        }

        // Convert an object to a byte array
        protected byte[] ObjectToByteArray(Object obj)
        {
            BinaryFormatter bf = new BinaryFormatter();
            using (var ms = new MemoryStream())
            {
                bf.Serialize(ms, obj);
                return ms.ToArray();
            }
        }

        /* Convert a byte array to an Object*/
        protected static Object ByteArrayToObject(byte[] arrBytes)
        {
            using (var memStream = new MemoryStream())
            {
                var binForm = new BinaryFormatter();
                memStream.Write(arrBytes, 0, arrBytes.Length);
                memStream.Seek(0, SeekOrigin.Begin);
                var obj = binForm.Deserialize(memStream);
                return obj;
            }
        }

    }
}
