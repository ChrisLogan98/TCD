﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NetLib;

namespace Chat_Program
{
    public partial class Form1 : Form
    {
        const int PORT = 11000;
        UDPConnection connection = new UDPConnection();

        public Form1()
        {
            InitializeComponent();
        }

        private void sTARTSERVERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            connection.StartServer(PORT);
            textBox1.AppendText("Server started\r\n");
            textBox1.AppendText("IP address: " + connection.GetLocalIP() + " \r\n");
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            connection.Close();
            Application.Exit();
        }

        private void cONNECTTOSERVERToolStripMenuItem_Click(object sender, EventArgs e)
        {
            NetworkForm nf = new NetworkForm();
            nf.ShowDialog();
            string ip = nf.GetIP();
            connection.StartClient(ip, PORT);
            textBox1.AppendText("Client started\r\n");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ChatMsg cm = new ChatMsg(textBox2.Text);
            connection.Send(cm);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(connection.HasData())
            {
                Object o = connection.Receive();
                if(o.GetType().Name == "ChatMsg")
                {
                    ChatMsg cm = (ChatMsg)o;
                    textBox1.AppendText(cm.msg + "\r\n");
                }
                else
                {
                    textBox1.AppendText("Unknown msg type: " + o.GetType().Name);
                }
            }
        }
    }
}
