﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fibonacci
{
    public partial class Form1 : Form
    {
        int[] fibs = new int[12];


        public Form1()
        {
            InitializeComponent();
            fibs[0] = 1;
            fibs[1] = 1;
            for (int i = 2; i < 12; i++)
            {
                fibs[i] = fibs[i - 1] + fibs[i - 2];
            }
        }

        private void aBOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("This was programmed by Chris Logan");

        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for (int i = 2; i < 12; i++)
            {
                textBox1.Text += "" + fibs[i] + "\r\n";
            }
        }
    }
}
