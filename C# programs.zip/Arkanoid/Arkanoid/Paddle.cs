﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Arkanoid
{
    class Paddle : GameObject
    {
        bool sticky = true;
        Image shortPaddle = global::Arkanoid.Properties.Resources.paddle_short;
        Image longPaddle = global::Arkanoid.Properties.Resources.paddle_long;

        public Paddle(int x, int y)
        {
            SetImage(global::Arkanoid.Properties.Resources.paddle_short);
            SetPosition(x, y);
            SetSpeed(5); //give the paddle a speed
        }

        public void SetSticky(bool yesNo)
        {
            sticky = yesNo;
        }

        public bool IsSticky()
        {
            return sticky;
        }
    }
}
