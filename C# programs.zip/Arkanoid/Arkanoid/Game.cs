﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Media;


namespace Arkanoid
{
    class Game
    {
        static Game instance = null;
        const int LEFT_EDGE = 30;
        const int RIGHT_EDGE = 360;
        const int TOP_EDGE = 30;
        const int SCREEN_HEIGHT = 450;
        const int PLAYER_Y = 420;
        const int TICKS_TO_RESET = 100;
        const int PLAYING = 1;
        const int RESETTING = 2;
        const int GAME_OVER = 3;
        int gameState = PLAYING;
        int currentLevel = 0;
        int lives = 3;
        int round = 0;
        int score = 0;
        int highScore = 0;
        Paddle paddle = new Paddle((RIGHT_EDGE - LEFT_EDGE) / 2, PLAYER_Y);
        List<GameObject> balls = new List<GameObject>();
        Random r = new Random();
        int ticks = 0;
        SoundPlayer brickHitSound = new SoundPlayer(global::Arkanoid.Properties.Resources.brickHitSound);
        SoundPlayer paddleHitSound = new SoundPlayer(global::Arkanoid.Properties.Resources.paddleHitSound);
        SoundPlayer enlargeSound = new SoundPlayer(global::Arkanoid.Properties.Resources.enlargeSound);
        SoundPlayer lostLifeSound = new SoundPlayer(global::Arkanoid.Properties.Resources.lostLifeSound);

        //CALL THIS FUNCTION TO GET A REFERENCE TO THE GAME
        //EXAMPLE : Game game = Game.GetInstance();
        public static Game GetInstance()
        {
            if (instance == null)
            {
                instance = new  Game();
            }
            return instance;
        }

 
        

        private Game()
        {
            Ball b = new Ball(100, 100);
            balls.Add(b);
            paddle.SetSticky(true);
            b.StuckToPaddle();
            LoadLevel();
        }

        private void LoadLevel()
        {

        }

        public void Draw(Graphics g)
        {
            paddle.Draw(g);
            DrawObjects(balls, g);
             
        }

        private void DrawObjects(List<GameObject> list, Graphics g)
        {
            foreach(GameObject o in list)
            {
                o.Draw(g);
            }
        }

        public void Update()
        {
            if(gameState == PLAYING)
            {
                UpdateGame();
            }
        }

        private void UpdateGame()
        {
            paddle.Update();
            foreach(Ball b in balls)
            {
                b.Update();
                if(b.GetX() < LEFT_EDGE || b.GetX() > RIGHT_EDGE)
                {
                    b.FlipDX();
                }
                else if(b.GetY() < TOP_EDGE)
                {
                    b.FlipDY();
                }

                if(b.GetBounds().IntersectsWith(paddle.GetBounds()))
                {
                    b.FlipDY();
                }
            }
        }

        public void Player1Up()
        {

        }


        public void Player1Down()
        {

        }
        
        public void Player1Left()
        {
            if(paddle.GetX() > 50)
            {
                paddle.MoveLeft();
            }
            
        }

        public void Player1Right()
        {
            if (paddle.GetX() < RIGHT_EDGE - 50)
            {
                paddle.MoveRight();
            }
        }

        public void Player1Fire()
        {

        }

        public void Player1Jump()
        {

        }

        public void Player2Up()
        {

        }

        public void Player2Down()
        {

        }

        public void Player2Left()
        {

        }

        public void Player2Right()
        {

        }

        public void Player2Fire()
        {

        }

        public void Player2Jump()
        {

        }

        public void Reset()
        {

        }
    }
}
