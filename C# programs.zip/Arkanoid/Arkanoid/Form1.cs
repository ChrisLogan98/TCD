﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Arkanoid
{
    public partial class Form1 : Form
    {
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern short GetAsyncKeyState(UInt16 virtualKeyCode);
        Game game = Game.GetInstance();

        public Form1()
        {
            InitializeComponent();
        }

        private void eXITToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void aBOUTToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("My last C# project. Feels bad man");
        }

        public void ReadKeyboard()
        {
            if (GetAsyncKeyState((ushort)Keys.A) != 0)
            {
                game.Player1Left();
            }
            else if (GetAsyncKeyState((ushort)Keys.D) != 0)
            {
                game.Player1Right();
            }
            if (GetAsyncKeyState((ushort)Keys.Space) != 0)
            {
                game.Reset();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            ReadKeyboard();
            game.Update();
            pictureBox1.Invalidate();
        }

        private void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
            game.Draw(e.Graphics);
        }
    }
}
