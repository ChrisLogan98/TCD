﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Arkanoid
{
    class Ball : GameObject
    {
        const int SPEED = 7;
        int dx = 1; //1 or -1
        int dy = 1;
        int ticks = 0;
        int TICKS_PER_STICK = 100;
        bool stuckToPaddle = false;

        public Ball(int x, int y)
        {
            SetImage(global::Arkanoid.Properties.Resources.ball);
        }

        public void StuckToPaddle()
        {
            stuckToPaddle = true;
        }

        public bool IsStuckToPaddle()
        {
            return stuckToPaddle;
        }

        public void Set1DX()
        {
            dx = 2 * Math.Sign(dx);
        }

        public void Set2DX()
        {
            dx = Math.Sign(dx);
        }

        public override void Update()
        {
            x += SPEED * dx;
            y += SPEED * dy;
        }

        public void FlipDX()
        {
            dx = dx * -1;
        }

        public void FlipDY()
        {
            dy = dy * -1;
        }

        public int GetDX()
        {
            return dx;
        }

        public int GetDY()
        {
            return dy;
        }
    }
}
